package com.example.familytree

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Member(
    val id: String,
    var name: String,
    var relation: String,
    var relatedTo: String
)

class MainActivity : Activity() {
    private val members = mutableListOf<Member>()
    private lateinit var container: LinearLayout
    private val prefs by lazy { getSharedPreferences("family_tree", MODE_PRIVATE) }
    private val relations = arrayOf("Root / Self", "Father", "Mother", "Husband", "Wife", "Son", "Daughter", "Brother", "Sister", "Grandfather", "Grandmother", "Other")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadMembers()
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 251))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(18))
            setBackgroundColor(Color.rgb(35, 72, 125))
        }
        header.addView(TextView(this).apply {
            text = "🌳  Family Tree"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        header.addView(TextView(this).apply {
            text = "Build and manage your family connections"
            textSize = 14f
            setTextColor(Color.rgb(225, 235, 250))
            setPadding(0, dp(6), 0, 0)
        })
        root.addView(header)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(8))
        }
        controls.addView(TextView(this).apply {
            text = "Family members (${members.size})"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(35, 48, 68))
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(Button(this).apply {
            text = "+ Add"
            setOnClickListener { showMemberDialog(null) }
        })
        root.addView(controls)

        val scroll = ScrollView(this)
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(24))
        }
        scroll.addView(container)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderCards()
    }

    private fun renderCards() {
        container.removeAllViews()
        if (members.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Your family tree is empty. Tap + Add to create the first person."
                textSize = 16f
                setTextColor(Color.GRAY)
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(50), dp(24), dp(50))
            })
            return
        }
        val sorted = members.sortedWith(compareBy<Member> { if (it.relation == "Root / Self") 0 else 1 }.thenBy { it.name.lowercase() })
        sorted.forEach { member ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(12), dp(12), dp(10))
                setBackgroundColor(Color.WHITE)
                elevation = dp(2).toFloat()
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(TextView(this).apply {
                text = member.name
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(32, 48, 70))
            })
            val relatedName = members.find { it.id == member.relatedTo }?.name
            val subtitle = if (member.relation == "Root / Self" || member.relatedTo.isBlank()) member.relation
                           else "${member.relation} of ${relatedName ?: "Unknown"}"
            details.addView(TextView(this).apply {
                text = subtitle
                textSize = 13f
                setTextColor(Color.rgb(100, 115, 135))
                setPadding(0, dp(3), 0, 0)
            })
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Edit"
                setOnClickListener { showMemberDialog(member) }
            })
            row.addView(Button(this).apply {
                text = "Delete"
                setOnClickListener { confirmDelete(member) }
            })
            card.addView(row)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = dp(10)
            container.addView(card, params)
        }
    }

    private fun showMemberDialog(existing: Member?) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val nameInput = EditText(this).apply {
            hint = "Full name"
            setSingleLine(true)
            setText(existing?.name ?: "")
        }
        val relationSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, relations)
            setSelection(relations.indexOf(existing?.relation ?: "Root / Self").coerceAtLeast(0))
        }
        val people = members.filter { it.id != existing?.id }
        val personLabels = listOf("Select related person") + people.map { it.name }
        val personSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, personLabels)
            val selectedIndex = people.indexOfFirst { it.id == existing?.relatedTo }
            setSelection(if (selectedIndex >= 0) selectedIndex + 1 else 0)
        }
        panel.addView(TextView(this).apply { text = "Name"; textSize = 13f })
        panel.addView(nameInput)
        panel.addView(TextView(this).apply { text = "Relationship"; textSize = 13f; setPadding(0, dp(12), 0, 0) })
        panel.addView(relationSpinner)
        panel.addView(TextView(this).apply { text = "Related to"; textSize = 13f; setPadding(0, dp(12), 0, 0) })
        panel.addView(personSpinner)

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Add family member" else "Edit family member")
            .setView(panel)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (name.isBlank()) {
                    Toast.makeText(this, "Please enter a name", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val relation = relationSpinner.selectedItem.toString()
                val related = if (relation == "Root / Self") "" else people.getOrNull(personSpinner.selectedItemPosition - 1)?.id ?: ""
                if (relation != "Root / Self" && related.isBlank()) {
                    Toast.makeText(this, "Select the person this member is related to", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                if (existing == null) members.add(Member(UUID.randomUUID().toString(), name, relation, related))
                else {
                    existing.name = name
                    existing.relation = relation
                    existing.relatedTo = related
                }
                saveMembers()
                render()
            }.show()
    }

    private fun confirmDelete(member: Member) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${member.name}?")
            .setMessage("This will remove this person from your family tree.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                members.removeAll { it.id == member.id }
                members.filter { it.relatedTo == member.id }.forEach { it.relatedTo = "" }
                saveMembers()
                render()
            }.show()
    }

    private fun saveMembers() {
        val array = JSONArray()
        members.forEach {
            array.put(JSONObject().put("id", it.id).put("name", it.name).put("relation", it.relation).put("relatedTo", it.relatedTo))
        }
        prefs.edit().putString("members", array.toString()).apply()
    }

    private fun loadMembers() {
        val raw = prefs.getString("members", null) ?: return
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                members.add(Member(o.getString("id"), o.getString("name"), o.optString("relation", "Other"), o.optString("relatedTo", "")))
            }
        } catch (_: Exception) { members.clear() }
    }
}
